#include <iostream>
#include <vector>
using namespace std;

int main() {
    freopen("info.out", "w", stdout);
    int cnt2 = 0;
    int maxn = 0, maxm = 0;
    vector<int> list;
    for (char c1 = 'A'; c1 <= 'Z'; c1 ++)
        for (int tc2 = 0; tc2 < 2; tc2 ++)
            for (int c3 = 8; c3 <= 28; c3 ++) {
                char c2 = (tc2 == 0 ? 'P' : 'B');
                char s[100];
                sprintf(s, "%c%c%d.txt", c1, c2, c3);
                freopen(s, "r", stdin);
                int n, m, cnt = 0; cin >> n >> m;
                maxn = max(maxn, n);
                maxm = max(maxm, m);
                for (int i = 0; i < n; i ++) {
                    string tmp; cin >> tmp;
                    for (int j = 0; j < tmp.size(); j ++)
                        if (tmp[j] == '1')
                            cnt ++;
                }
                list.push_back(cnt);
                cnt2 += cnt;
                printf("%s : size=%d*%d, nb=%d\n", s, n, m, cnt);
            }
    printf("=================\n");
    sort(list.begin(), list.end());
    for (int i = 0; i < list.size(); i ++)
        printf("list[%d] = %d\n", i, list[i]);
    printf("=================\n");
    printf("maxn = %d maxm = %d\n", maxn, maxm);
    printf("total nb = %d\n", cnt2);
}
